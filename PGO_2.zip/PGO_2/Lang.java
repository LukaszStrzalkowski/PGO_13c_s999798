public enum Lang {
    English,
    Polish,
    Japanese,
    Ukrainian
}