public enum Genre {
    Adventure,
    Classic,
    Comics,
    Detective,
    Fantasy,
    Fiction
}